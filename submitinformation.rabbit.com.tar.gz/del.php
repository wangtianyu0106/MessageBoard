<meta charset="UTF-8">
<?php
$id = $_GET["id"];
//引入连接数据库的配置文件
require_once "config.php";

//删除数据
mysqli_query($conn,"DELETE FROM `submitinformati`.`user` WHERE `user`.`id` = $id");
//返回上个页面
header('Location:/');
//本地调试
//header('Location:/submitinformation.rabbit.com/list.php');