<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>信息收集--列表</title>
    <link href="https://cdn.bootcss.com/twitter-bootstrap/4.1.3/css/bootstrap.css" rel="stylesheet">
</head>
<body>
<?php
//引入连接数据库的配置文件
require_once "config.php";

//查询数据库
$resultAll = mysqli_query($conn,"SELECT * FROM  `user` ORDER BY `user`.`id` DESC ");
//var_dump($resultAll);

//查询出数据库中有多少条数据
$length = mysqli_num_rows($resultAll);
//var_dump($length);

?>
<div class="container">
    <h1 class="text-center" style="margin: 25px 0">信息收集--列表</h1>
    <table class="table">
        <thead class="thead-dark">
        <tr>
            <th scope="col">ID</th>
            <th scope="col">姓名</th>
            <th scope="col">年龄</th>
            <th scope="col">编辑</th>
        </tr>
        </thead>
        <tbody>
        <?php
        for($i=0;$i<$length;$i++){
            //输出第一条数据
            $result = mysqli_fetch_assoc($resultAll);
//            var_dump($result);
            $id = $result["id"];
            $user = $result["user"];
            $age = $result["age"];
            ?>
        <tr>
            <th scope="row"><?php echo $id; ?></th>
            <td><?php echo $user; ?></td>
            <td><?php echo $age; ?></td>
            <td>
                <a href="edit.php?id=<?php echo $id;?>&user=<?php echo $user; ?>&age=<?php echo $age ;?>" type="button" class="btn btn-info">修改</a>
                <a href="del.php?id=<?php echo $id; ?>" type="button" class="btn btn-danger">删除</a>
            </td>
        </tr>
        <?php
        }
        ?>
        </tbody>
    </table>
  <p class="footer-p"><a href="http://www.beian.miit.gov.cn">冀ICP备18033167号</a></p> 
        <p class="footer-p"><a href="http://www.beian.miit.gov.cn">冀ICP备18033167号-1</a></p> 
</div>
</body>
</html>