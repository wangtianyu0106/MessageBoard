<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h4>get方法</h4>
<form action="add.php" method="get">
    <input type="text" name="name" placeholder="请输入姓名">
    <input type="text" name="age" placeholder="请输入年龄">
    <input type="submit" value="提交">
  <p class="footer-p"><a href="http://www.beian.miit.gov.cn">冀ICP备18033167号</a></p> 
        <p class="footer-p"><a href="http://www.beian.miit.gov.cn">冀ICP备18033167号-1</a></p> 
</form>
<hr>
</body>
</html>