<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<?php
$id = $_GET["id"];
$user = $_GET["user"];
$age = $_GET["age"];
?>
<h4>get方法</h4>
<form action="update.php" method="get">
    <input type="text" name="id" value="<?php echo $id; ?>" readonly="readonly">
    <input type="text" name="name" placeholder="请输入姓名" value="<?php echo $user; ?>">
    <input type="text" name="age" placeholder="请输入年龄" value="<?php echo $age; ?>">
    <input type="submit" value="提交">
</form>
  <p class="footer-p"><a href="http://www.beian.miit.gov.cn">冀ICP备18033167号</a></p> 
        <p class="footer-p"><a href="http://www.beian.miit.gov.cn">冀ICP备18033167号-1</a></p> 
<hr>
</body>
</html>