<?php
//连接MySQL数据库
$conn = mysqli_connect("localhost","submitinformati","wy3Xx4ZxiR","submitinformati") or die("连接失败");
//本地调试
//$conn = mysqli_connect("localhost","root","root","submitinformati") or die("连接失败");
//var_dump($conn);

//连接完数据库后确定插入数据的编码格式
mysqli_query($conn,'set names utf8');