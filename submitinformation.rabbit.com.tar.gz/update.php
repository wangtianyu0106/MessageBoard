<meta charset="UTF-8">
<?php
$d = $_GET["id"];
$n = $_GET["name"];
$a = $_GET["age"];

//引入连接数据库的配置文件
require_once "config.php";

//增加数据
mysqli_query($conn,"UPDATE  `submitinformati`.`user` SET  `user` =  '$n',`age` =  '$a' WHERE  `user`.`id` =$d;");
//返回上个页面
header('Location:/list.php');
//本地调试
//header('Location:/submitinformation.rabbit.com/list.php');