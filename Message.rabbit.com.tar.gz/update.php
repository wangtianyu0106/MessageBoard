<meta charset="UTF-8">
<?php
$id = $_GET["id"];
$user = $_GET["user"];
$massage = $_GET["massage"];

//引入连接数据库的配置文件
require_once "config.php";

//修改数据
mysqli_query($conn,"UPDATE  `$sql`.`massage` SET  `user` =  '$user',`massage` =  '$massage' WHERE  `massage`.`id` =$id;");
echo "<script>alert('修改成功！^-^');location.href='/list.php'</script>";
//返回上个页面
//header('Location:/list.php');
//header('Location:/Message.rabbit.com/list.php');