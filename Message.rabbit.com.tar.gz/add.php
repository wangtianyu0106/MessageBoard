<meta charset="UTF-8">
<?php
$n = $_POST["name"];
$a = $_POST["main"];

//引入连接数据库的配置文件
require_once "config.php";

//增加数据
if($n=="" || $a==""){
    echo "<script>alert('请输入内容');location.href='/'</script>";
}else{
    mysqli_query($conn,"INSERT INTO `Message_rabbit_`.`massage` (`id`, `user`, `massage`) VALUES (NULL, '$n', '$a');");
    //mysqli_query($conn,"INSERT INTO `$sql`.`massage` (`id`, `user`, `massage`) VALUES (NULL, '$n', '$a');");
     //返回上个页面
    //header('Location:/');
    echo "<script>alert('感谢您的留言，留言成功！');location.href='/'</script>";
}


