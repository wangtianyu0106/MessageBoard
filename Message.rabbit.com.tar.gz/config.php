<?php
//连接MySQL数据库
$conn = mysqli_connect("localhost","Message_rabbit_","WDspaXbwen","Message_rabbit_") or die("连接失败");
//本地调试
//$conn = mysqli_connect("localhost","root","root","Message_rabbit_") or die("连接失败");

//连接完数据库后确定插入数据的编码格式
mysqli_query($conn,'set names utf8');

//数据库名
$sql = 'Message_rabbit_';