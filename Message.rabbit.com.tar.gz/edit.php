<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.bootcss.com/twitter-bootstrap/4.1.3/css/bootstrap.css" rel="stylesheet">
    <style>
        * {
            padding: 0;
            margin: 0;
        }
        h1 {
            padding: 50px 0;
            text-align: center;
            font-family: 华文行楷;
            width: 220px;
            font-size: 55px;
            background: linear-gradient(to right, #dcace0, #06dcf4);
            margin:0 auto;
            -webkit-background-clip: text;
            color: transparent;
        }
        .container-fluid {
            width: 100%;
            padding-right: 0;
            padding-left: 0;
            margin-right: auto;
            margin-left: auto;
        }
        .container-fluid .inner-top{
            background-image: url(img/bg1.jpg);
            background-repeat: no-repeat;
            background-size: 100%;
            height: 100%;
            padding-bottom: 100px;
        }
        .mb-3 {
            margin-bottom: 3rem !important;
        }
        .form-control {
            background-color: rgba(225, 225, 225, 0.5);
        }
        .container-fluid {
            position: relative;
        }
        .look {
            position: absolute;
            /*top: 100%;*/
            left: 50%;
            transform: translateX(-50%);
        }
        .btn-secondary {
            color: #17a2b8;
            background-color: rgba(255, 255, 255, 0.62);
            border-color: #17a2b8;
        }
        .btn-secondary:hover {
            color: #fff;
            background-color: #17a2b8;
            border-color: #17a2b8;
        }
        .btn-secondary:focus {
            box-shadow: 0 0 0 0.2rem rgba(23, 162, 184, 0.32);
        }
        .btn-secondary:not(:disabled):not(.disabled):active, {
            color: #fff;
            background-color: #17a2b8;
            border-color: #17a2b8;
        }
        .container-fluid .massage {
            padding-bottom: 50px;
            padding-top: 100px;
            position: relative;
        }
        .massage-bg{
            background: -webkit-linear-gradient(right top,#71dbf3,#cc9bd2);
            background: -o-linear-gradient(left top,#71dbf3,#cc9bd2);
            background: -moz-linear-gradient(left top,#71dbf3,#cc9bd2);
            background: -mos-linear-gradient(left top,#71dbf3,#cc9bd2);
            background: linear-gradient(left top,#71dbf3,#cc9bd2);
            background-repeat: no-repeat;
            background-size: 100% 100%;
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
            filter: blur(3px);
            text-align: center;
            background-size: cover;
        }
        .alert-info {
            color: #263b3e;
            background-color: rgba(209, 236, 241, 0.55);
            border-color: #bee5eb;
        }
        .table {
            position: relative;
            z-index: 100;
            background-color: rgba(255, 253, 253, 0.46);
        }
        .alert h3 {
            margin: 20px 0;
        }
    </style>
</head>
<body>
<?php
$id = $_GET["id"];
$user = $_GET["user"];
$massage = $_GET["massage"];
?>
<div class="container-fluid">
    <div class="inner-top">
        <div class="container">
            <!--    &nbsp;=>多个空格-->
            <h1>留&nbsp;言&nbsp;板</h1>
            <form action="update.php" method="get">
                <div class="input-group mb-3" style="display:none;">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">ID</span>
                    </div>
                    <input type="text" name="id" value="<?php echo $id; ?>" readonly="readonly" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">用&nbsp;&nbsp;户&nbsp;&nbsp;名</span>
                    </div>
                    <input type="text" name="user" value="<?php echo $user; ?>" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">留言&nbsp;内容</span>
                    </div>
                    <textarea type="text"  rows="5" name="massage" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default"><?php echo $massage; ?></textarea>
                </div>
                <input type="submit" value="修改留言" class="btn btn-primary">
            </form>
        </div>
    </div>
</div>
</body>
</html>