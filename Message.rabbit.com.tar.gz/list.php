<?php
require_once "config.php";
//启动session会话
session_start();

//判断登录赋值
if($_SESSION['user'] !== 1){
//登录失败跳转页面
    header('Location:/admin/login.php');
};
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=`, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>留言信息表</title>
    <link href="https://cdn.bootcss.com/twitter-bootstrap/4.1.3/css/bootstrap.css" rel="stylesheet">
    <style>
        .alert h3{
            margin: 20px 0;
        }
        .look {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            right: 2%;
        }
        .btn-secondary {
            color: #17a2b8;
            background-color: rgba(255, 255, 255, 0.62);
            border-color: #17a2b8;
        }
        .btn-secondary:hover {
            color: #fff;
            background-color: #17a2b8;
            border-color: #17a2b8;
        }
        .btn-secondary:focus {
            box-shadow: 0 0 0 0.2rem rgba(23, 162, 184, 0.32);
        }
        .btn-secondary:not(:disabled):not(.disabled):active, {
            color: #fff;
            background-color: #17a2b8;
            border-color: #17a2b8;
        }
      @media (max-width:600px){
           .alert h3 {
               font-size: 20px;
            }
      }
    </style>
</head>
<body>
<?php

//引入连接数据库的配置文件
require_once "config.php";

//查询数据库
$resultAll = mysqli_query($conn,"SELECT * FROM  `massage` ORDER BY  `massage`.`id` DESC ");
//var_dump($resultAll);

//查询出数据库中有多少条数据
$length = mysqli_num_rows($resultAll);
//var_dump($length);

?>
<div class="container">
    <div class="alert alert-info text-center" role="alert">
        <h3>留言信息--列表</h3>
        <a href="index.php" class="btn btn-secondary look" role="button" aria-disabled="true">返回首页</a>
    </div>
    <table class="table table-striped text-center">
        <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">用户名</th>
            <th scope="col">留言内容</th>
            <th scope="col">编辑</th>
        </tr>
        </thead>
        <tbody>
        <?php
        for ($i=0;$i<$length;$i++){
        $result = mysqli_fetch_assoc($resultAll);
//        var_dump($result);
        $id = $result["id"];
        $user = $result["user"];
        $massage = $result["massage"];
        ?>
        <tr>
            <th scope="row"><?php echo $id; ?></th>
            <td><?php echo $user; ?></td>
            <td class="lynr" style="width:500px"><?php echo nl2br($massage); ?></td>
            <td>
                <button class="btn btn-outline-info"><a href="edit.php?id=<?php echo $id;?>&user=<?php echo $user; ?>&massage=<?php echo $massage ;?>"  style="color: #000">修改</a></button>
                <button class="btn btn-outline-danger" id="myBtn"><a href="del.php?id=<?php echo $id;?>" onclick="return confirm('确定要删除吗？')" style="color: #000">删除</a></button>
            </td>
        </tr>
        <?php
        }
        ?>
        </tbody>
    </table>
</div>
</body>
</html>