#格式

index.php =>首页，添加留言;

    add.php =>添加数据到list.php;
    
list.php =>数据后台管理页面;

    del.php =>删除数据;
    
    config.php =>配置文件;
    
edit.php =>修改留言页面;

    update.php =>刷新修改后的留言;
