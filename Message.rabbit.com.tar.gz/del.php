<meta charset="UTF-8">
<?php
$id = $_GET["id"];


//引入连接数据库的配置文件
require_once "config.php";

//删除数据
//mysqli_query($conn,"DELETE FROM `$sql`.`massage` WHERE `massage`.`id` = $id");
mysqli_query($conn,"DELETE FROM `Message_rabbit_`.`massage` WHERE `massage`.`id` = $id");

//返回上个页面
header('Location:/list.php');
//header('Location:/Message.rabbit.com/list.php');