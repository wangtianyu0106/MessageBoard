<?php
//post方法接收到用户名
session_start();
$user = $_POST["user"];

//post方法接收到用户密码
$password = $_POST["password"];
var_dump($_POST);
//判断用户名和用户密码是否匹配
if($user == "user" && $password == "02020026@wqwty"){
    //跳转页面
  $_SESSION['user']=1;
  header('Location:../list.php');
}else{
   $_SESSION['user']=0;
    //跳转页面
  header('Location:login.php');
}