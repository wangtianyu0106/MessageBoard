<?php
//启动session会话
session_start();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=`, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>留言后台管理登录</title>
    <style>
        body{
            background: -webkit-radial-gradient(#6FA58D,#123B73);
            background: -o-radial-gradient(#6FA58D,#123B73);
            background: -moz-radial-gradient(#6FA58D,#123B73);
            background: radial-gradient(#6FA58D,#123B73);
            background-size:100% 100%;
            background-attachment: fixed;
        }
        .container{
            width: 300px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%,-50%);
        }
        .container input{
            margin: auto;
            display: block;
            padding: 10px 25px;
            border-radius: 20px;
            margin-bottom: 15px;
            border: 1px #a5a5a5 solid;
        }
        .container .submit{
            padding: 10px 35px;
        }
        .container{
            color: #fff9ec;
            text-align: center;
        }
        .container h2{
            font-family: 方正行楷简体;
            font-weight: 100;
            font-size: 36px;
        }
        .container .password,.container .user{
            background-color: transparent;
        }
        input::-webkit-input-placeholder,textarea::-webkit-input-placeholder{
            color:#fff9ec;
        }

        input:-moz-placeholder,textarea:-moz-placeholder{
            color:#fff9ec;
        }

        input::-moz-placeholder,textarea::-moz-placeholder{
            color:#fff9ec;
        }
        input:-ms-input-placeholder,textarea:-ms-input-placeholder{
            color:#fff9ec;
        }
      @media (max-width:600px) {
            .container h2{
                font-family: 方正行楷简体;
                font-weight: 100;
                font-size: 25px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h2>留言后台管理登录</h2>
    <form action="login-if.php" method="post">
        <input type="text" name="user" placeholder="用户名" class="user">
        <input type="password" name="password" placeholder="用户密码" class="password">
        <input type="submit" value="登录" class="submit">
    </form>
</div>
  <?php
if(isset($_SESSION['user'])){
    if($_SESSION['user'] !== 1){
        echo "<script>alert('账号或密码错误')</script>";
        session_destroy();
    }
};
?>
</body>
</html>