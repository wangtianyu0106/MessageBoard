<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=`, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.bootcss.com/twitter-bootstrap/4.1.3/css/bootstrap.css" rel="stylesheet">
    <style>
        * {
            padding: 0;
            margin: 0;
        }
        h1 {
            padding: 50px 0;
            text-align: center;
            font-family: 华文行楷;
            width: 220px;
            font-size: 55px;
            background: linear-gradient(to right, #dcace0, #06dcf4);
            margin:0 auto;
            -webkit-background-clip: text;
            color: transparent;
        }
        .container-fluid {
            width: 100%;
            padding-right: 0;
            padding-left: 0;
            margin-right: auto;
            margin-left: auto;
        }
        .container-fluid .inner-top{
            background-image: url(img/bg1.jpg);
            background-repeat: no-repeat;
            background-size: 100%;
            height: 100%;
            padding-bottom: 100px;
        }
        .mb-3 {
            margin-bottom: 3rem !important;
        }
        .form-control {
            background-color: rgba(225, 225, 225, 0.5);
        }
        .container-fluid {
            position: relative;
        }
        .look {
            position: absolute;
            /*top: 100%;*/
            left: 50%;
            transform: translateX(-50%);
        }
        .btn-secondary {
            color: #17a2b8;
            background-color: rgba(255, 255, 255, 0.62);
            border-color: #17a2b8;
        }
        .btn-secondary:hover {
            color: #fff;
            background-color: #17a2b8;
            border-color: #17a2b8;
        }
        .btn-secondary:focus {
            box-shadow: 0 0 0 0.2rem rgba(23, 162, 184, 0.32);
        }
        .btn-secondary:not(:disabled):not(.disabled):active, {
            color: #fff;
            background-color: #17a2b8;
            border-color: #17a2b8;
        }
        .container-fluid .massage {
            padding-bottom: 50px;
            padding-top: 100px;
            position: relative;
        }
        .massage-bg{
            background: -webkit-linear-gradient(right top,#71dbf3,#cc9bd2);
            background: -o-linear-gradient(left top,#71dbf3,#cc9bd2);
            background: -moz-linear-gradient(left top,#71dbf3,#cc9bd2);
            background: -mos-linear-gradient(left top,#71dbf3,#cc9bd2);
            background: linear-gradient(left top,#71dbf3,#cc9bd2);
            background-repeat: no-repeat;
            background-size: 100% 100%;
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
            filter: blur(3px);
            text-align: center;
            background-size: cover;
        }
        .alert-info {
            color: #263b3e;
            background-color: rgba(209, 236, 241, 0.55);
            border-color: #bee5eb;
        }
        .table {
            position: relative;
            z-index: 100;
            background-color: rgba(255, 253, 253, 0.46);
        }
        .alert h3 {
            margin: 20px 0;
        }
        .footer {
           position: relative;
           z-index: 100;
           padding: 30px 0px 20px 0px; 
           text-align: center; 
       }
      .footer-bg {
           background: -webkit-linear-gradient(right top,#cc88bc,#cc9bd2);
           background: -o-linear-gradient(left top,#cc88bc,#cc9bd2);
           background: -moz-linear-gradient(left top,#cc88bc,#cc9bd2);
           background: -mos-linear-gradient(left top,#cc88bc,#cc9bd2);
           background: linear-gradient(left top,#cc88bc,#cc9bd2);
           background-repeat: no-repeat;
           filter: blur(3px);
           background-size: 100% 100%;
           width: 100%;
           height: 100%;
           position: absolute;
           top: 0;
           left: 0;
           background-size: cover;
           z-index: -1;
      }
      @media (max-width:600px){
            .top-bg{
                  background: -webkit-linear-gradient(left bottom,#71dbf3,#cc9bd2);
                  background: -o-linear-gradient(left bottom,#71dbf3,#cc9bd2);
                  background: -moz-linear-gradient(left bottom,#71dbf3,#cc9bd2);
                  background: -mos-linear-gradient(left bottom,#71dbf3,#cc9bd2);
                  background: linear-gradient(left bottom,#71dbf3,#cc9bd2);
                  background-repeat: no-repeat;
                  /*background-size: 100% 100%;*/
                  width: 100%;
                  height: 600px;
                  position: absolute;
                  top: 0;
                  left: 0;
                  filter: blur(3px);
                  text-align: center;
                  background-size: cover;
                  z-index: -1;
          }
          .container-fluid .inner-top{
                 background: none;
         }
          h1 {;
                color: rgba(0, 0, 0, 0.63);
        }
      }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="inner-top">
      <div class="top-bg"></div>
        <div class="container">
            <!--    &nbsp;=>多个空格-->
            <h1>留&nbsp;言&nbsp;板</h1>
            <?php

//            echo '<script>
//                            document.getElementById("submit").addEventListener("click", function(){
//                                var r = confirm("请输入内容！");
//                                var name = document.getElementById("name");
//                                var main = document.getElementById("main");
//                                if(name.value =="" && main.value ==""){
//                                    r;
//                                    location.href = "index.php";
//                                }else{
//                                    location.href = "add.php";
//                                }
//                            });
//                    </script>';
//            ?>
            <form method="post" action="add.php">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">用&nbsp;&nbsp;户&nbsp;&nbsp;名</span>
                    </div>
                    <input type="text" name="name" id="name" placeholder="请输入用户名" autofocus="autofocus" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">留言&nbsp;内容</span>
                    </div>
                    <textarea type="text"  rows="5" name="main" id="main" placeholder="请输入留言内容" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default"></textarea>
                </div>
                <input id="submit" type="submit" value="提交留言" class="btn btn-primary">
            </form>
            <a href="../list.php" class="btn btn-secondary look" role="button" aria-disabled="true">查看后台留言列表</a>
        </div>
    </div>

    <?php
    //引入连接数据库的配置文件
    require_once "config.php";

    //查询数据库
    $resultAll = mysqli_query($conn,"SELECT * FROM  `massage` ORDER BY  `massage`.`id` DESC ");
    //var_dump($resultAll);

    //查询出数据库中有多少条数据
    $length = mysqli_num_rows($resultAll);
    //var_dump($length);
    ?>
    <div class="massage">
        <div class="massage-bg"></div>
        <div class="container">
            <div class="alert alert-info text-center" role="alert">
                <h3>留&nbsp;&nbsp;言&nbsp;&nbsp;信&nbsp;&nbsp;息</h3>
            </div>
            <table class="table table-striped text-center">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">用&nbsp;&nbsp;户&nbsp;&nbsp;名</th>
                    <th scope="col">留言&nbsp;内容</th>
                </tr>
                </thead>
                <tbody>
                <?php
                for ($i=0;$i<$length;$i++){
                    $result = mysqli_fetch_assoc($resultAll);
//        var_dump($result);
                    $id = $result["id"];
                    $user = $result["user"];
                    $massage = $result["massage"];
                    ?>
                    <tr>
                        <th scope="row"><?php echo $id; ?></th>
                        <td><?php echo $user; ?></td>
                        <td style="width:700px"><?php echo nl2br($massage); ?></td>
                        <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    </tr>
                    <?php
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>
  <div class="footer container-fluid">
    <div class="footer-bg"></div>
    <div class="container">
        <p class="footer-p"><a href="http://www.beian.miit.gov.cn">冀ICP备18033167号</a></p> 
        <p class="footer-p"><a href="http://www.beian.miit.gov.cn">冀ICP备18033167号-1</a></p> 
    </div>	
  </div>
</div>
</body>
</html>