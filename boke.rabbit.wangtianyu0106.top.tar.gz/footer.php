
<div class="footer">
    <p>
        <span>&copy; 2018</span>
        <span><a href="http://www.layui.com" target="_blank">闲言</a></span>
        <span>MIT license</span>
    </p>
    <p><span>人生就是一场修行</span></p>
  <p class="footer-p"><a href="http://www.beian.miit.gov.cn">冀ICP备18033167号</a></p> 
        <p class="footer-p"><a href="http://www.beian.miit.gov.cn">冀ICP备18033167号-1</a></p> 
</div>
<script src="res/layui/layui.js"></script>
<script>
    layui.config({
        base: 'res/static/js/'
    }).use('blog');
</script>
</body>
</html>