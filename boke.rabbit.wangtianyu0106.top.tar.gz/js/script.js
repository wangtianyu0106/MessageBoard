function like(e)
{
    var xmlhttp;
    if (window.XMLHttpRequest)
    {
        //  IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
        xmlhttp=new XMLHttpRequest();
    }
    else
    {
        // IE6, IE5 浏览器执行代码
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange=function()
    {
        if (xmlhttp.readyState==4 && xmlhttp.status==200)
        {
            // console.log(xmlhttp.responseText);
            var id = document.querySelector("#like"+e+" em");
            if(id != null){
                id.innerHTML=xmlhttp.responseText;
            }
        }
    }
    xmlhttp.open("GET","like.php?id="+e,true);
    xmlhttp.send();
}

// 留言板点赞功能
function message_like(e)
{
    var xmlhttp;
    if (window.XMLHttpRequest)
    {
        //  IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
        xmlhttp=new XMLHttpRequest();
    }
    else
    {
        // IE6, IE5 浏览器执行代码
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange=function()
    {
        if (xmlhttp.readyState==4 && xmlhttp.status==200)
        {
            // console.log(xmlhttp.responseText);
            var id = document.querySelector("#message_like"+e+" em");
            if(id != null){
                id.innerHTML=xmlhttp.responseText;
            }
        }
    }
    xmlhttp.open("GET","message_like.php?id="+e,true);
    xmlhttp.send();
}

// 关于点赞功能
function about_like(e)
{
    var xmlhttp;
    if (window.XMLHttpRequest)
    {
        //  IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
        xmlhttp=new XMLHttpRequest();
    }
    else
    {
        // IE6, IE5 浏览器执行代码
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange=function()
    {
        if (xmlhttp.readyState==4 && xmlhttp.status==200)
        {
            // console.log(xmlhttp.responseText);
            var id = document.querySelector("#about_like"+e+" em");
            if(id != null){
                id.innerHTML=xmlhttp.responseText;
            }
        }
    }
    xmlhttp.open("GET","about_like.php?id="+e,true);
    xmlhttp.send();
}

// 评论点赞功能
function talk_like(e)
{
    var xmlhttp;
    if (window.XMLHttpRequest)
    {
        //  IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
        xmlhttp=new XMLHttpRequest();
    }
    else
    {
        // IE6, IE5 浏览器执行代码
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange=function()
    {
        if (xmlhttp.readyState==4 && xmlhttp.status==200)
        {
            // console.log(xmlhttp.responseText);
            var id = document.querySelector("#talk_like"+e+" em");
            if(id != null){
                id.innerHTML=xmlhttp.responseText;
            }
        }
    }
    xmlhttp.open("GET","talk_like.php?id="+e,true);
    xmlhttp.send();
}

//添加留言
// var item_btn = document.querySelector("#item-btn");
// if(item_btn !== null){
//     item_btn.addEventListener("click",function () {
//         var xmlhttp;
//         if (window.XMLHttpRequest)
//         {
//             //  IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
//             xmlhttp=new XMLHttpRequest();
//         }
//         else
//         {
//             // IE6, IE5 浏览器执行代码
//             xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
//         }
//         xmlhttp.onreadystatechange=function()
//         {
//             if (xmlhttp.readyState==4 && xmlhttp.status==200)
//             {
//                 // console.log(xmlhttp.responseText);
//             }
//         }
//         xmlhttp.open("GET","message-add.php?text="+document.querySelector("#LAY-msg-content").value,true);
//         xmlhttp.send();
//     })
// }


// 留言翻页
function messagePage(id) {
    var xmlhttp;
    if (window.XMLHttpRequest)
    {
        //  IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
        xmlhttp=new XMLHttpRequest();
    }
    else
    {
        // IE6, IE5 浏览器执行代码
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange=function()
    {
        if (xmlhttp.readyState==4 && xmlhttp.status==200)
        {
            // document.getElementById("myDiv").innerHTML=xmlhttp.responseText;
            document.querySelector(".info-box").innerHTML=xmlhttp.responseText;
        }
    }
    xmlhttp.open("GET","message-item.php?message="+id,true);
    xmlhttp.send();
}