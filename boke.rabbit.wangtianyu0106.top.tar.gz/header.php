<?php
//引入配置文件
require_once "config.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>闲言轻博客</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="res/layui/css/layui.css">
    <link rel="stylesheet" href="res/static/css/mian.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="lay-blog">
<div class="header">
    <div class="header-wrap">
        <h1 class="logo pull-left">
            <a href="index.php">
                <img src="res/static/images/logo.png" alt="" class="logo-img">
                <img src="res/static/images/logo-text.png" alt="" class="logo-text">
            </a>
        </h1>
        <form class="layui-form blog-seach pull-left" action="">
            <div class="layui-form-item blog-sewrap">
                <div class="layui-input-block blog-sebox">
                    <i class="layui-icon layui-icon-search"></i>
                    <input type="text" name="search" lay-verify="title" autocomplete="off"  class="layui-input">
                </div>
            </div>
        </form>
        <div class="blog-nav pull-right">
            <ul class="layui-nav pull-left">
                <li class="layui-nav-item layui-this"><a href="index.php">首页</a></li>
                <li class="layui-nav-item"><a href="message.php">留言</a></li>
                <li class="layui-nav-item"><a href="about.php">关于</a></li>
                <li class="layui-nav-item"><a href="help.php">帮助</a></li>
            </ul>
            <a href="admin/index.php" class="personal pull-left">
                <i class="layui-icon layui-icon-username"></i>
            </a>
        </div>
        <div class="mobile-nav pull-right" id="mobile-nav">
            <a href="javascript:;">
                <i class="layui-icon layui-icon-more"></i>
            </a>
        </div>
    </div>
    <ul class="pop-nav" id="pop-nav">
        <li><a href="index.php">首页</a></li>
        <li><a href="message.php">留言</a></li>
        <li><a href="about.php">关于</a></li>
        <li><a href="help.php">帮助</a></li>
    </ul>
</div>