<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
<?php
//启动session会话
session_start();
//引入配置文件
require_once "config.php";

$sessionId = $_SESSION['user'];
$resultUser = mysqli_query($conn,"SELECT * FROM `users` WHERE `id` =$sessionId");
$resUser = mysqli_fetch_assoc($resultUser);
$name = $resUser["name"];
$pic = $resUser["pic"];

//$name = "凌落成诗";

//$pic = "res/static/images/info-img.png";

$text = $_POST["text"];
//var_dump($name);
//var_dump($pic);
//var_dump($text);

//操作数据表
mysqli_query($conn,"INSERT INTO `boke`.`message` (`id`, `name`, `text`, `pic`, `like`) VALUES (NULL, '$name', '$text', '$pic', '0');");
header('Location:message.php');