<?php
//链接数据库
//$conn = mysqli_connect("localhost","root","root","boke") or die("连接失败");
$conn = mysqli_connect("localhost","boke_rabbit_wan","jHxHYMGae5","boke_rabbit_wan") or die("连接失败");
//连接完数据库后确定插入数据的编码格式
mysqli_query($conn,'set names utf8');