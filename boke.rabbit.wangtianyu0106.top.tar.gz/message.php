<?php
require_once "config.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>留言-闲言轻博客</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="res/layui/css/layui.css">
	<link rel="stylesheet" href="res/static/css/mian.css">
</head>
<body class="lay-blog">
		<div class="header">
			<div class="header-wrap">
				<h1 class="logo pull-left">
					<a href="index.php">
						<img src="res/static/images/logo.png" alt="" class="logo-img">
						<img src="res/static/images/logo-text.png" alt="" class="logo-text">
					</a>
				</h1>
				<form class="layui-form blog-seach pull-left" action="">
					<div class="layui-form-item blog-sewrap">
					    <div class="layui-input-block blog-sebox">
					      <i class="layui-icon layui-icon-search"></i>
					      <input type="text" name="title" lay-verify="title" autocomplete="off"  class="layui-input">
					    </div>
					</div>
				</form>
				<div class="blog-nav pull-right">
					<ul class="layui-nav pull-left">
					  <li class="layui-nav-item"><a href="index.php">首页</a></li>
					  <li class="layui-nav-item  layui-this"><a href="message.php">留言</a></li>
					  <li class="layui-nav-item"><a href="about.php">关于</a></li>
					  <li class="layui-nav-item"><a href="help.php">帮助</a></li>
					</ul>
					<a href="admin/index.php" class="personal pull-left">
						<i class="layui-icon layui-icon-username"></i>
					</a>
				</div>
				<div class="mobile-nav pull-right" id="mobile-nav">
					<a href="javascript:;">
						<i class="layui-icon layui-icon-more"></i>
					</a>
				</div>
			</div>
			<ul class="pop-nav" id="pop-nav">
				<li><a href="index.php">首页</a></li>
				<li><a href="message.php">留言</a></li>
				<li><a href="about.php">关于</a></li>
				<li><a href="help.php">帮助</a></li>
			</ul>
		</div>
		<div class="container-wrap">
			<div class="container container-message">
				<div class="contar-wrap" id="contar-wrap">
					<form class="layui-form" action="message-add.php" method="post">
						<div class="layui-form-item layui-form-text">
							  <textarea class="layui-textarea" name="text" id="LAY-msg-content" style="resize:none"></textarea>
						</div>
					<div class="item-btn">
						<button class="layui-btn layui-btn-normal" id="item-btn">提交</button>
					</div>
                    </form>
					<div id="LAY-msg-box">
						<div class="info-box">
                            <?php
                            //查询数据库
                            $messageAll = mysqli_query($conn,"SELECT * FROM `message` ORDER BY `message`.`id` DESC");
                            //查询出数据库中有多少条数据
                            $length = mysqli_num_rows($messageAll);

                            require_once "message-item.php";
                            ?>
						</div>
					</div>+
					<div class="paging">
                        <div class="layui-box layui-laypage layui-laypage-molv" id="layui-laypage-1">
                            <a href="javascript:;" class="layui-laypage-prev layui-disabled" data-page="0">上一页</a>
                            <span class="layui-laypage-curr">
                                <em class="layui-laypage-em" style="background-color:#1e9fff;"></em><em>1</em>
                            </span>
                            <a href="javascript:;" onclick="messagePage(2)" date-page="2">2</a>
                            <a href="javascript:;" onclick="messagePage(3)" date-page="3">3</a>
                            <a href="javascript:;" onclick="messagePage(4)" date-page="4">4</a>
                            <a href="javascript:;" onclick="messagePage(5)" date-page="5">5</a>
                            <a class="layui-laypage-next" data-page="2">下一页</a>
                        </div>
                    </div>
				</div>
			</div>
		</div>
		<div class="footer">
			<p>
				<span>&copy; 2018</span>
				<span><a href="http://www.layui.com" target="_blank">layui.com</a></span> 
				<span>MIT license</span>
			</p>
			<p><span>人生就是一场修行</span></p>
          <p class="footer-p"><a href="http://www.beian.miit.gov.cn">冀ICP备18033167号</a></p> 
        <p class="footer-p"><a href="http://www.beian.miit.gov.cn">冀ICP备18033167号-1</a></p> 
		</div>
	</div>
	<script src="res/layui/layui.js">

	</script>
	<script>		
		layui.config({
		  base: 'res/static/js/' 
		}).use('blog');
	</script>

<!--	<script id="LAY-msg-tpl" type="text/html">-->
<!--		<div class="info-box">-->
<!--			<div class="info-item">-->
<!--                <img class="info-img" src="{{d.avatar}}" alt="">-->
<!--			  <div class="info-text">-->
<!--					<p class="title">-->
<!--					  <span class="name">{{d.username}}</span>-->
<!--					  <span class="info-img">-->
<!--					  	<i class="layui-icon layui-icon-praise"></i>-->
<!--					  	{{ d.praise }}-->
<!--					 	</span>-->
<!--					</p>-->
<!--					<p class="info-intr">-->
<!--						{{ d.content }}-->
<!--					</p>-->
<!--			  </div>-->
<!--			</div>-->
<!--		</div>-->
<!--	 </script>-->
        <script src="js/script.js"></script>
</body>
