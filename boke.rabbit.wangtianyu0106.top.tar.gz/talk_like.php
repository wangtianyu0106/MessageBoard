<meta charset="UTF-8">
<?php
//引入配置文件
require_once "config.php";
//获取id
//var_dump($_GET);
$id = $_GET["id"];
//var_dump($id);
//查询字段
$res = mysqli_query($conn,"SELECT * FROM `talk` WHERE `id` =$id");
//var_dump($res);
$r = mysqli_fetch_assoc($res);
//echo "<pre>";
//var_dump($r);
//echo "</pre>";
$like = $r["like"];
//var_dump($like);
//转int类型 并且 加1
$like = (int)$like + 1;
//var_dump($like);
$result = mysqli_query($conn,"UPDATE `boke`.`talk` SET `like` = '$like' WHERE `talk`.`id` =$id;");
//输出like
echo $like;