##PHP博客程序描述文件
###项目结构
####前台页面结构
- 404.html     无法找到网页的提示页面
- about.php    关于页面
- comment.php  文章写评论页面
- details.php  文章详情页（带评论列表）
- footer.php   前端全局底部
- header.php   前段全局头部
- index.php    网站首页
- message.php  留言页面
####后台页面结构
- admin/
    - footer.php    后台全局底部
    - header.php    后台全局头部
    - index.php     后台首页（仪表盘）
    - login.php     后台登录页面
    - login-if.php  后台登录页面判断是否登录成功的功能
    - login-out.php 退出页面（销毁session值的功能）
    - post.php      文章-所有文章的列表
    - post-add.php  文章-写文章-点击发布按钮的form提交页面
    - post-del.php  文章-文章列表-点击删除按钮的form弹出框删除页面
    - post-edit.php 文章-所有文章-单片文章的编辑功能
    - post-edit-update.php 文章-所有文章-单篇文章编辑后的保存数据库的功能
    - post-new.php  文章-写文章页面
    - setting-notice.php   公告设置页面
    - update-notice.php    常规设置-公告设置，把公告保存到数据库的功能
####样式及事件包
- css/(前段自定义样式文件(包括scss))

- res/(前段模板自带的样式和事件包)