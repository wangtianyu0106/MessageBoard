<?php
require_once "header.php";
?>
		<div class="container-wrap">
			<div class="container">
					<div class="contar-wrap">
						<h4 class="item-title">
                            <?php
                            //查询数据库
                            $resultAll = mysqli_query($conn,"SELECT * FROM `notice`");
                            //输出第一条数据
                            $result = mysqli_fetch_assoc($resultAll);
                            $content = $result["content"];
                            ?>
							<p><i class="layui-icon layui-icon-speaker"></i>公告：<span><?php echo $content; ?></span></p>
						</h4>

                        <?php

                        if(isset($_GET["search"])){
                            $search = $_GET["search"];
//                            var_dump($search);
                            echo "<h5 style='margin-bottom: 15px'>搜索关键词<span style='color: #FF5722'>".$search."</span>的结果为:</h5>";
                        }
                            //翻页功能
                            if(isset($_GET["page"])){
                                $page = $_GET["page"];
//                                var_dump("当前页是".$page);
                            }else{
                                $page = 1;
                            }

                            //post中有多少篇文章
                        if(isset($_GET["search"])){
                            $postAll = mysqli_query($conn,"SELECT * FROM `posts` WHERE `title` LIKE '%$search%' OR `comment` LIKE '%$search%'");
                        }else{
                            $postAll = mysqli_query($conn,"SELECT * FROM `posts`");
                        }
//                            $postAll = mysqli_query($conn,"SELECT * FROM `posts`");
                            $postLength = mysqli_num_rows($postAll);
//                            var_dump($pagesLength);

                            $pageShow = 5;

                            $postnum = ceil($postLength / $pageShow);
//                            var_dump($postnum);
                        //从$pageNumber开始显示往后$pageShow个
                            $pageNumber = ($page - 1) * $pageShow;
//                            var_dump($pageNumber);

                            //翻页按钮（下一页）
                            $pageNext = $page + 1;

                            // （上一页）
                             $pagePrev = $page - 1;
                        //查询数据库
                        if(isset($_GET["search"])){
                            $postsAll = mysqli_query($conn,"SELECT * FROM `posts` WHERE `title` LIKE '%$search%' OR `comment` LIKE '%$search%' ORDER BY `posts`.`id` DESC LIMIT $pageNumber , $pageShow");
                        }else{
                            $postsAll = mysqli_query($conn,"SELECT * FROM `posts` ORDER BY `posts`.`id` DESC LIMIT $pageNumber , $pageShow");
                        }
//                        $postsAll = mysqli_query($conn,"SELECT * FROM `posts` ORDER BY `posts`.`id` DESC LIMIT $pageNumber , $pageShow");
                        //查询出数据库中有多少条数据
                        $postsLength = mysqli_num_rows($postsAll);
//                        var_dump($postsLength);
                        ?>
                        <?php
                        for($i=0;$i<$postsLength;$i++){
                            //输出第一条数据
                            $result = mysqli_fetch_assoc($postsAll);
//                            echo "<pre>";
//                            var_dump($result);
//                            echo "</pre>";
                            $id = $result["id"];
                            $time = $result["time"];
                            $title = $result["title"];
                            $comment = $result["comment"];
                            $pic = $result["pic"];
                            ?>


						<div class="item">
							<div class="item-box  layer-photos-demo1 layer-photos-demo">
								<h3><a href="details.php?p=<?php echo $id;?>"><?php echo $title ;?></a></h3>
								<h5>发布于：<span><?php echo $time ;?></span></h5>
								<p><?php
                                    if(strlen($comment) > 300){
//                                        $comment超出300个字符后就显示...
                                        echo mb_substr($comment, 0, 300, 'utf-8')."...[<a href='details.php?p=$id'>点击阅读</a>]";
                                    }else{
                                        echo nl2br($comment);
                                    }
                                    ?>
                                </p>
								<img src="<?php echo $pic ;?>" alt="">
							</div>
							<div class="comment count">
								<a href="details.php?p=<?php echo $id;?>#comment">评论</a>
								<a href="javascript:;" onclick="like(<?php echo $id; ?>)" class="like">点赞</a>
							</div>
						</div>
                            <?php
                        }
                        ?>
					</div>
					<div class="item-btn">
                        <?php
                        if($page == 1){
                        }else {
                            ?>
                            <button class="layui-btn layui-btn-normal"><a href = "?page=1" style="color: white">首 页</a></button>
                            <button class="layui-btn layui-btn-normal"><a href = "?page=<?php echo $pagePrev;?>" style="color: white">上一页</a></button>
                        <?php
                        }
                        ?>
                        <?php
                        if($page < $postnum){
                            ?>
						    <button class="layui-btn layui-btn-normal"><a href="?page=<?php echo $pageNext;?>" style="color: white">下一页</a></button>
                            <button class="layui-btn layui-btn-normal"><a href="?page=<?php echo $postnum;?>" style="color: white">尾页</a></button>
                            <?php
                        }else{

                        }
                        echo "<p style='margin-top: 20px;font-size: 16px'>第".$page."页</p>"
                        ?>
                    </div>
			</div>
		</div>
    <script src="js/script.js"></script>
<?php
require_once "footer.php";
?>