<?php
require_once "config.php";
//翻页功能
if(isset($_GET["message"])){
    $message = $_GET["message"];
    //var_dump("当前页是".$message);
}else{
    $message = 1;
    //var_dump("当前页是".$message);
}
$messageAll = mysqli_query($conn,"SELECT * FROM `message`");
$messageLength = mysqli_num_rows($messageAll);
//var_dump($messageLength);

$messageShow = 5;

$messagenum = ceil($messageLength / $messageShow);
//var_dump($messagenum);
//从$pageNumber开始显示往后$pageShow个
$messageNumber = ($message - 1) * $messageShow;
//var_dump($messageNumber);

//翻页按钮（下一页）
$messageNext = $message + 1;

// （上一页）
$messagePrev = $message - 1;
//查询出数据库
$messagesAll = mysqli_query($conn,"SELECT * FROM `message` ORDER BY `message`.`id` DESC LIMIT $messageNumber , $messageShow");
//查询出数据库中有多少条数据
$messageLength = mysqli_num_rows($messagesAll);
?>
<?php
for($i=0;$i<$messageLength;$i++){
    //输出第一条数据
    $result = mysqli_fetch_assoc($messagesAll);
    //echo "<pre>";
    //var_dump($result);
    //echo "</pre>";
    $id = $result["id"];
    $name = $result["name"];
    $text = $result["text"];
    $pic = $result["pic"];
    $like = $result["like"];
    ?>
    <div class="info-item">
        <img class="info-img" style="width: 68px" src="<?php echo $pic; ?>" alt="">
        <div class="info-text">
            <p class="title count">
                <span class="name"><?php echo $name; ?></span>
                <span class="info-img like" id="message_like<?php echo $id; ?>" onclick="message_like(<?php echo $id; ?>)"><i class="layui-icon layui-icon-praise"></i><em><?php echo $like; ?></em></span>
            </p>
            <p class="info-intr"><?php echo $text;?></p>
        </div>
    </div>
    <?php
}
?>