<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
<?php
//启动session会话
session_start();
//var_dump($_GET);
$id = $_GET["p"];
$text = $_GET["text"];
//var_dump($id);
//var_dump($text);

//引入配置文件
require_once "config.php";
//$name = "孤独患者";
//$pic = "res/static/images/info-img.png";

$sessionId = $_SESSION['user'];
$resultUser = mysqli_query($conn,"SELECT * FROM `users` WHERE `id` =$sessionId");
$resUser = mysqli_fetch_assoc($resultUser);
$name = $resUser["name"];
$pic = $resUser["pic"];
//var_dump($name);
//var_dump($pic);
mysqli_query($conn,"INSERT INTO `boke`.`talk` (`id`, `post_id`, `name`, `pic`, `text`, `like`) VALUES (NULL, '$id', '$name', '$pic', '$text', '0');");

header("Location:details.php?p=$id#comment");