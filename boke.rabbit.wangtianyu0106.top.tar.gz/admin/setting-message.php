<?php
require_once "header.php";
//if ($level ! = 1){
//die("权限不足，不能访问");
//}
?>
    <div class="col-12" style="background: #edfffd; margin-bottom: 15px">
        <h5>修改个人信息</h5>
    </div>
<!--    <h5>修改个人信息</h5>-->
    <form class="form-horizontal notice-form row" style="width: 100%" action="setting-message-edit.php" method="post" enctype="multipart/form-data">
        <div class="form-group col-4">
            <label for="inputEmail3" class="col-sm-2 control-label">昵称：</label>
            <div class="col-sm-10">
                <input type="text" name="setting_message_name" autofocus="autofocus" class="form-control" value="<?php echo $user; ?>">
            </div>
        </div>
        <div class="form-group col-4">
            <label for="inputPassword3" class="col-sm-2 control-label">电话：</label>
            <div class="col-sm-10">
              <input type="text" name="setting_message_tel" class="form-control" value="<?php echo $tel; ?>">
            </div>
        </div>
        <div class="form-group col-4">
            <label for="inputPassword3" class="col-sm-2 control-label">头像设置：</label>
            <div class="col-sm-10">
                <img style="width:80px;border-radio:100%;" src="<?php echo "../".$pic ;?>">
                <input type="file" name="file">
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-primary">确定修改</button>
            </div>
        </div>
    </form>
</div>
<?php
require_once "footer.php";
?>