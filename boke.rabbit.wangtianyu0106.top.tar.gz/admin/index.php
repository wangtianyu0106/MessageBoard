<?php
require_once "header.php";
?>
    <div class="col-12" style="background: #edfffd; margin-bottom: 15px">
        <h5>个人信息</h5>
    </div>
    <!--头像-->
    <div class="col-2" style="background: #edfffd;">
        <ul style="margin-bottom: 0;">
            <li style="text-align: center;padding-top: 10px;padding-bottom: 10px;font-weight: 700;">头像:</li>
        </ul>
    </div>
    <div class="col-6" style="background: #edfffd;">
        <ul style="margin-bottom: 0;">
            <li style="padding-top: 10px;padding-bottom: 10px">
                <img src="<?php echo "../".$pic;?>" alt="" style="width: 70px;">
            </li>
        </ul>
    </div>
    <div class="col-4" style="background: #edfffd;"></div>
    <!--头像-->
    <!--用户名-->
    <div class="col-2" style="background: #edfffd;">
        <ul style="margin-bottom: 0;">
            <li style="text-align: center;padding-top: 10px;padding-bottom: 10px;font-weight: 700;">用户:</li>
        </ul>
    </div>
    <div class="col-6" style="background: #edfffd;">
        <ul style="margin-bottom: 0;">
            <li style="padding-top: 10px;padding-bottom: 10px"><?php echo $user; ?></li>
        </ul>
    </div>
    <div class="col-4" style="background: #edfffd;"></div>
    <!--用户名-->
    <!--昵称-->
    <div class="col-2" style="background: #edfffd;">
        <ul style="margin-bottom: 0;">
            <li style="text-align: center;padding-top: 10px;padding-bottom: 10px;font-weight: 700;">昵称:</li>
        </ul>
    </div>
    <div class="col-6" style="background: #edfffd;">
        <ul style="margin-bottom: 0;">
            <li style="padding-top: 10px;padding-bottom: 10px"><?php echo $name; ?></li>
        </ul>
    </div>
    <div class="col-4" style="background: #edfffd;"></div>
    <!--昵称-->
    <!--电话-->
    <div class="col-2" style="background: #edfffd;">
        <ul style="margin-bottom: 0;">
            <li style="text-align: center;padding-top: 10px;padding-bottom: 10px;font-weight: 700;">电话:</li>
        </ul>
    </div>
    <div class="col-6" style="background: #edfffd;">
        <ul style="margin-bottom: 0;">
            <li style="padding-top: 10px;padding-bottom: 10px"><?php echo $tel; ?></li>
        </ul>
    </div>
    <div class="col-4" style="background: #edfffd;"></div>
    <!--电话-->
</div>
<?php
require_once "footer.php";
?>