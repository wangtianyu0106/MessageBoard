<?php
require_once "header.php";
?>
    <div class="col-12" style="background: #edfffd; margin-bottom: 15px">
        <h5>写文章</h5>
    </div>
<!--<h5>写文章</h5>-->
    <form class="form-horizontal notice-form" style="width: 90%" action="post-add.php" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">标题：</label>
            <div class="col-sm-10">
                <input type="text" name="title" autofocus="autofocus" class="form-control" placeholder="请输入标题">
            </div>
        </div>
        <div class="form-group">
            <label for="inputPassword3" class="col-sm-2 control-label">文章内容：</label>
            <div class="col-sm-10">
                <textarea class="form-control" name="comment" rows="3" placeholder="请输入文章内容"></textarea>
            </div>
        </div>
        <div class="form-group">
            <label for="inputPassword3" class="col-sm-2 control-label">图片连接：</label>
            <div class="col-sm-10">
                <input type="file" name="file">
            </div>
        </div>
        <div class="form-group">
            <label for="inputPassword3" class="col-sm-2 control-label">发布时间：</label>
            <div class="col-sm-10">
                <input type="datetime-local" name="time" value="<?php echo date("Y");?>-<?php echo date("m");?>-<?php echo date("d");?>T<?php echo date("H");?>:<?php echo date("i");?>">
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-primary">发布</button>
            </div>
        </div>
    </form>
<?php
require_once "footer.php";
?>