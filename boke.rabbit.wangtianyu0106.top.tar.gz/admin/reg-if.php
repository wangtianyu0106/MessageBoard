<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
<?php
//var_dump($_POST);
require_once "../config.php";

$user = $_POST["user"];
$password = $_POST["password"];
$name = $_POST["name"];
$tel = $_POST["tel"];
//var_dump($user);

$reg = mysqli_query($conn,"SELECT * FROM `users` WHERE `user` LIKE '$user'");
$regLen = mysqli_num_rows($reg);
//var_dump($regLen);

if($regLen === 0){
    //长度等于0时，说明数据库中没有这个账号，就可以注册
    mysqli_query($conn,"INSERT INTO `boke`.`users` (`id`, `user`, `password`, `name`, `tel`, `pic`, `level`) VALUES (NULL, '$user', '$password', '$name', '$tel', 'img/user.png', '2');");
    header('Location:login.php');
}