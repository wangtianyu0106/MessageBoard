<meta charset="UTF-8">
<?php
//引入连接数据库的配置文件
require_once "../config.php";
//var_dump($_GET);
$id = $_GET["id"];
//删除数据
mysqli_query($conn,"DELETE FROM `boke`.`message` WHERE `message`.`id` =$id");
//返回上个页面
header('Location:message.php');