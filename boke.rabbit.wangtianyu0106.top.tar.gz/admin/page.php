<?php
require_once "header.php";
if ($level != 1){
    die("权限不足，不能访问");
}
?>
    <div class="col-12" style="background: #edfffd; margin-bottom: 15px">
        <h5>网页列表</h5>
    </div>
<!--    <h4 style="padding-top: 10px;padding-bottom: 10px">网页列表</h4>-->
    <table class="table table-striped text-center" style="background: #edfffd;">
        <thead>
        <tr>
            <th scope="col">用户名ID</th>
            <th scope="col">网页标题</th>
            <!--            <th scope="col">文章内容</th>-->
            <th scope="col">编辑</th>
        </tr>
        </thead>
        <tbody>
        <?php
        //引入连接数据库的配置文件
        require_once "../config.php";

        //查询数据库
        $result = mysqli_query($conn,"SELECT * FROM `pages` ORDER BY `pages`.`id` ASC");
        //        var_dump($result);

        //查询出数据库中有多少条数据
        $length = mysqli_num_rows($result);
        //        var_dump($length);

        ?>
        <?php
        for($i=0;$i<$length;$i++) {
            //输出第一条数据
            $res = mysqli_fetch_assoc($result);
//            echo "<pre>";
//            var_dump($res);
//            echo "</pre>";
            $id = $res["id"];
            $title = $res["title"];
            ?>
            <tr>
                <th scope="row"><?php echo $id; ?></th>
                <td class="post-bt"><?php echo $title; ?></td>
                <td>
                    <button class="btn btn-outline-info"><a href="post-edit.php?id=<?php echo $id;?>" style="color: #000">修改</a></button>
                    <button class="btn btn-outline-danger" id="myBtn"><a href="post-del.php?id=<?php echo $id;?>" onclick="return confirm('确定要删除吗？')" style="color: #000">删除</a></button>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>
<?php
//echo '<script>
//        document.getElementById("myBtn").addEventListener("click", function(){
//            var r = confirm("确定删除这篇文章？且不可恢复！");
//            if(r){
//                location.href = "post-del.php";
//            }else{
//                location.href = "post.php";
//            }
//        });
//</script>';
//?>
<?php
require_once "footer.php";
?>