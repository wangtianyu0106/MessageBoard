<?php
require_once "header.php";
?>
    <div class="col-12" style="background: #edfffd; margin-bottom: 15px">
        <h5>留言列表</h5>
    </div>
<!--    <h4 style="padding-top: 10px;padding-bottom: 10px">留言列表</h4>-->
    <table class="table table-striped text-center" style="background: #edfffd;">
        <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">用户名</th>
            <th scope="col">留言内容</th>
<!--            <th scope="col">编辑</th>-->
            <th scope="col">点赞量</th>
            <th scope="col">删除</th>
        </tr>
        </thead>
        <tbody>
        <?php
        //引入连接数据库的配置文件
        require_once "../config.php";

        //查询数据库
        $result = mysqli_query($conn,"SELECT * FROM `message` ORDER BY `message`.`id` DESC");
        //        var_dump($result);

        //查询出数据库中有多少条数据
        $length = mysqli_num_rows($result);
        //        var_dump($length);

        ?>
        <?php
        //翻页功能
        if(isset($_GET["message"])){
            $message = $_GET["message"];
//                                var_dump("当前页是".$message);
        }else{
            $message = 1;
//                                var_dump("当前页是".$message);
        }
        if($level ==1){
            $messageAll = mysqli_query($conn,"SELECT * FROM `message`");
            $messageLength = mysqli_num_rows($messageAll);
            //var_dump($messageLength);

            $messageShow = 6;

            $messagenum = ceil($messageLength / $messageShow);
            //var_dump($messagenum);

            //从$pageNumber开始显示往后$pageShow个
            $messageNumber = ($message - 1) * $messageShow;
            //var_dump($messageNumber);

            //翻页按钮（下一页）
            $messageNext = $message + 1;

            // （上一页）
            $messagePrev = $message - 1;
            //查询出数据库
            $messagesAll = mysqli_query($conn,"SELECT * FROM `message` ORDER BY `message`.`id` DESC LIMIT $messageNumber , $messageShow");
            //查询出数据库中有多少条数据
            $messageLength = mysqli_num_rows($messagesAll);
        }else if($level == 2){
            $messageAll = mysqli_query($conn,"SELECT * FROM `message` WHERE `user_id` =$sessionId");
            $messageLength = mysqli_num_rows($messageAll);
            //                            var_dump($messageLength);

            $messageShow = 6;

            $messagenum = ceil($messageLength / $messageShow);
            //var_dump($messagenum);

            //从$pageNumber开始显示往后$pageShow个
            $messageNumber = ($message - 1) * $messageShow;
            //var_dump($messageNumber);

            //翻页按钮（下一页）
            $messageNext = $message + 1;

            // （上一页）
            $messagePrev = $message - 1;


            //查找对应作者id的文章
            $messagesAll = mysqli_query($conn,"SELECT * FROM `message` WHERE `user_id` =$sessionId");
            //    var_dump($sessionId);
            //查询数据库中有多少条数据
            $messageLength = mysqli_num_rows($messagesAll);
        }
        ?>
        <?php
//        if($level ==1){
        for($i=0;$i<$messageLength;$i++) {
            //输出第一条数据
            $res = mysqli_fetch_assoc($messagesAll);
//            echo "<pre>";
//            var_dump($res);
//            echo "</pre>";
            $id = $res["id"];
            $user_id = $sessionId;
//            var_dump($id);
            $name = $res["name"];
            $pic = $res["pic"];
            $text = $res["text"];
            $like = $res["like"];
            ?>
            <tr>
                <th scope="row"><?php echo $id; ?></th>
                <td class="post-bt">
                    <img src="<?php echo "../" . $pic; ?>" style="width: 38px;float: left; margin-left: 20px;" alt="">
                    <p style="float: left; margin-top: 10px; margin-left: 10px"><?php echo $name; ?></p>
                </td>
                <td class="post-bt" style="width: 400px">
                    <p><?php echo $text; ?></p>
                </td>
                <!--                <td>-->
                <!--                    <button class="btn btn-outline-danger" id="myBtn"><a href="post-del.php?id=-->
                <?php //echo $id;?><!--" style="color: #000">删除</a></button>-->
                <!--                </td>-->
                <td class="post-bt">
                    <p><?php echo $like; ?></p>
                </td>
                <td class="post-bt">
                    <button class="btn btn-outline-danger" id="myDel">
                        <a href="message-del.php?id=<?php echo $id; ?>" onclick="return confirm('确定要删除吗？')"
                           style="color: #000">删除</a>
                    </button>
                </td>
            </tr>
            <?php
            }
            ?>
        </tbody>
    </table>
</div>
<?php
//echo '<script>
//        document.getElementById("myDel").addEventListener("click", function(){
//            var r = confirm("确定删除这条留言？且不可恢复！");
//            if(r){
//                location.href = "message-del.php";
//            }else{
//                location.href = "message.php";
//            }
//        });
//</script>';
//?>
<?php
require_once "footer.php";
?>