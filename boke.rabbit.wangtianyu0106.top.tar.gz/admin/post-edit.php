<?php
require_once "header.php";

if ($level != 1){
    die("权限不足，不能访问");
}
?>
<?php
//获取编辑内容
//echo "<pre>";
//var_dump($_GET);
//echo "</pre>";
$id = $_GET["id"];

//查询语句获取指定id的内容
$result = mysqli_query($conn,"SELECT * FROM `posts` WHERE `id` =$id ORDER BY `posts`.`id` DESC");

$res = mysqli_fetch_assoc($result);
//echo "<pre>";
//var_dump($res);
//echo "</pre>";
//标题
$title = $res["title"];
//正文
$comment = $res["comment"];
//时间
$time = $res["time"];
//图片地址
$pic = $res["pic"];
//阅读量
$read = $res["read"];
//点赞量
$like = $res["like"];
?>
    <div class="col-12" style="background: #edfffd; margin-bottom: 15px">
        <h5>修改文章</h5>
    </div>
<!--    <h5>修改文章</h5>-->
    <form class="form-horizontal notice-form" style="width: 90%" action="post-edit-update.php" method="post" enctype="multipart/form-data">
        <div class="form-group" style="display: none">
            <label for="inputEmail3" class="col-sm-2 control-label">id：</label>
            <div class="col-sm-10">
                <input type="text" name="id" value="<?php echo $id; ?>" class="form-control" placeholder="请输入标题">
            </div>
        </div>
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">标题：</label>
            <div class="col-sm-10">
                <input type="text" name="title" value="<?php echo $title; ?>" autofocus="autofocus" class="form-control" placeholder="请输入标题">
            </div>
        </div>
        <div class="form-group">
            <label for="inputPassword3" class="col-sm-2 control-label">文章内容：</label>
            <div class="col-sm-10">
                <textarea class="form-control" name="comment" rows="3" placeholder="请输入文章内容"><?php echo $comment; ?></textarea>
            </div>
        </div>
        <div class="form-group">
            <label for="inputPassword3" class="col-sm-2 control-label">图片连接：</label>
            <div class="col-sm-10">
                <input type="file" name="file" value="<?php echo $pic; ?>">
            </div>
        </div>
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">更新时间：</label>
            <div class="col-sm-10">
                <input type="text" value="<?php echo $time; ?>" name="time">
            </div>
        </div>
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">阅读量：</label>
            <div class="col-sm-10">
                <input type="text" value="<?php echo $read; ?>" name="read">
            </div>
        </div>
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">点赞量：</label>
            <div class="col-sm-10">
                <input type="text" value="<?php echo $like; ?>" name="like">
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-primary">发布</button>
            </div>
        </div>
    </form>
</div>
<?php
require_once "footer.php";
?>