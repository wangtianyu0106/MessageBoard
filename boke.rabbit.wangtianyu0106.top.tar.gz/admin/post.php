<?php
require_once "header.php";
?>
    <div class="col-12" style="background: #edfffd; margin-bottom: 15px">
        <h5>文章列表</h5>
    </div>
    <!--    <h4 style="padding-top: 10px;padding-bottom: 10px">文章列表</h4>-->
    <table class="table table-striped text-center" style="background: #edfffd;">
        <thead>
        <tr>
            <th scope="col">文章ID</th>
            <th scope="col">文章标题</th>
            <!--            <th scope="col">文章内容</th>-->
            <th scope="col">编辑</th>
        </tr>
        </thead>
        <tbody>
        <?php
        //引入连接数据库的配置文件
        require_once "../config.php";

        //查询数据库
        $result = mysqli_query($conn, "SELECT * FROM `posts` ORDER BY `posts`.`id` DESC");
        //        var_dump($result);

        //查询出数据库中有多少条数据
        $length = mysqli_num_rows($result);
        //        var_dump($length);

        ?>
        <?php
        //翻页功能
        if (isset($_GET["page"])) {
            $page = $_GET["page"];
//                                var_dump("当前页是".$page);
        } else {
            $page = 1;
        }

        if($level ==1){

            //post中有多少篇文章
            $postAll = mysqli_query($conn, "SELECT * FROM `posts`");
            $postLength = mysqli_num_rows($postAll);

            $pageShow = 7;

            $postnum = ceil($postLength / $pageShow);
            //var_dump($postnum);
            //从$pageNumber开始显示往后$pageShow个
            $pageNumber = ($page - 1) * $pageShow;
            //var_dump($pageNumber);

            //翻页按钮（下一页）
            $pageNext = $page + 1;

            //（上一页）
            $pagePrev = $page - 1;

            //查询数据库
            $postsAll = mysqli_query($conn, "SELECT * FROM `posts` ORDER BY `posts`.`id` DESC LIMIT $pageNumber , $pageShow");
            //查询出数据库中有多少条数据
            $postsLength = mysqli_num_rows($postsAll);
            //var_dump($postsLength);
        }else if($level == 2){
            //post中有多少篇文章
            $postAll = mysqli_query($conn, "SELECT * FROM `posts` WHERE `user_id` =$sessionId");
            $postLength = mysqli_num_rows($postAll);


            $pageShow = 7;

            $postnum = ceil($postLength / $pageShow);
            //var_dump($postnum);
            //从$pageNumber开始显示往后$pageShow个
            $pageNumber = ($page - 1) * $pageShow;
            //var_dump($pageNumber);

            //翻页按钮（下一页）
            $pageNext = $page + 1;

            //（上一页）
            $pagePrev = $page - 1;

            //查找对应作者id的文章
            $postsAll = mysqli_query($conn,"SELECT * FROM `posts` WHERE `user_id` =$sessionId");
            //    var_dump($sessionId);
            //查询数据库中有多少条数据
            $postsLength = mysqli_num_rows($postsAll);
        }
        //var_dump($pagesLength);
        ?>
        <?php
//        if ($level == 1){
        for ($i = 0; $i < $postsLength; $i++) {
            //输出第一条数据
            $res = mysqli_fetch_assoc($postsAll);
//            echo "<pre>";
//            var_dump($res);
//            echo "</pre>";
            $id = $res["id"];
            $title = $res["title"];
            ?>
            <tr>
                <th scope="row"><?php echo $id; ?></th>
                <td class="post-bt" style="width: 624px;">
                    <?php
                    if (strlen($title) > 20) {
//                                        $comment超出20个字符后就显示...
                        echo mb_substr($title, 0, 20, 'utf-8') . "......";
                    } else {
                        echo nl2br($title);
                    }
                    ?>
                    <!--                    --><?php //echo $title; ?>
                </td>
                <td>
                    <button class="btn btn-outline-info"><a href="post-edit.php?id=<?php echo $id; ?>"
                                                            style="color: #000">修改</a></button>
                    <button class="btn btn-outline-danger" id="myBtn"><a href="post-del.php?id=<?php echo $id; ?>"
                                                                         onclick="return confirm('确定要删除吗？')"
                                                                         style="color: #000">删除</a></button>
                </td>
            </tr>
        <?php
}
?>
    </tbody>
    </table>
    <div class="post-btns">
        <?php
        if ($page == 1) {
        } else {
            ?>
            <button class="btn btn-primary"><a href="?page=1" style="color: white">首 页</a></button>
            <button class="btn btn-primary"><a href="?page=<?php echo $pagePrev; ?>" style="color: white">上一页</a>
            </button>
            <?php
        }
        ?>
        <?php
        if ($page < $postnum) {
            ?>
            <button class="btn btn-primary"><a href="?page=<?php echo $pageNext; ?>" style="color: white">下一页</a>
            </button>
            <button class="btn btn-primary"><a href="?page=<?php echo $postnum; ?>" style="color: white">尾页</a></button>
            <?php
        } else {

        }
        //        echo "<p style='margin-top: 20px;font-size: 16px'>第".$message."页</p>"
        ?>
    </div>
    </div>
<?php
//echo '<script>
//        document.getElementById("myBtn").addEventListener("click", function(){
//            var r = confirm("确定删除这篇文章？且不可恢复！");
//            if(r){
//                location.href = "post-del.php";
//            }else{
//                location.href = "post.php";
//            }
//        });
//</script>';
//?>
<?php
require_once "footer.php";
?>