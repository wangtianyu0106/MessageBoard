<?php
//启动session会话
session_start();

//销毁session会话
session_unset();

//跳转页面
header('Location:login.php');