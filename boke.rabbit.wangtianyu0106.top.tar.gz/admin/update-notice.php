<?php
//引入配置文件
require_once "../config.php";
require_once "admin-config.php";

//获取公告内容
$notice = $_GET["notice"];
if($level == 1){
//修改数据
    mysqli_query($conn,"UPDATE  `boke`.`notice` SET  `content` =  '$notice' WHERE  `notice`.`id` =1;");
//跳转页面
    header('Location:setting-notice.php');
}else{
//跳转页面
    header('Location:index.php');
}