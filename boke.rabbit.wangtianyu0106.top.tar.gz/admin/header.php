<?php
require_once "../config.php";
//启动session会话
session_start();

//判断登录赋值
if(!isset($_SESSION['user'])){
//登录失败跳转页面
    header('Location:login.php');
};
require_once "admin-config.php";
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.bootcss.com/twitter-bootstrap/4.1.3/css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <title>我的博客后台设置</title>
</head>
<body>
<div class="container-fluid">
    <div class="row" style="padding-bottom: 50px">
        <div class="col-2 col2">
            <nav>
                <ul>
                    <img src="<?php echo "../".$pic;?>" class="user-pic" alt="">
                    <h1 class="user"><?php echo $name?></h1>
                </ul>
                <ul class="nav-ul">
                    <li class="xnav">
                        <h2>仪表盘</h2>
                        <ul>
                            <li>
                                <a href="index.php">个人信息</a>
                            </li>
                            <li>
                                <a href="setting-message.php">信息编辑</a>
                            </li>
                        </ul>
                    </li>
                    <?php
                    if($level == 1) {

                        ?>
                        <li class="xnav">
                            <h2>页面设置</h2>
                            <ul>
                                <li>
                                    <a href="page.php">所有页面</a>
                                </li>
<!--                                <li>-->
<!--                                    <a href="">新建页面</a>-->
<!--                                </li>-->
                            </ul>
                        </li>
                        <?php
                    }
                    ?>
                    <li class="xnav">
                        <h2>文章设置</h2>
                        <ul>
                            <li>
                                <a href="post.php">所有文章</a>
                            </li>
                            <li>
                                <a href="post-new.php">写文章</a>
                            </li>
                        </ul>
                    </li>
                    <li class="xnav">
                        <h2>留言设置</h2>
                        <ul>
                            <li>
                                <a href="message.php">所有留言</a>
                            </li>
                        </ul>
                    </li>
                    <?php
//                    var_dump($level);
                    if($level == 1){

                    ?>
                    <li class="xnav">
                        <h2>常规设置</h2>
                        <ul>
                            <li>
                                <a href="setting-notice.php">公告设置</a>
                            </li>
                        </ul>
                    </li>
                    <?php
                    }
                    ?>
                </ul>
            </nav>
        </div>
        <div class="col-10">
            <div class="row">
                <div class="col-12 top clearfix">
                    <a class="left" href="../index.php">返回前台</a>
                    <p class="right1">欢迎，<?php echo $name; ?></p>
                    <a class="right" href="login-out.php">登出</a>
                    <h1 class="text-center">我的博客后台设置</h1>
                </div>
