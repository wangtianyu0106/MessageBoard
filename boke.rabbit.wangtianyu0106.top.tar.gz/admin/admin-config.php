<?php
$sessionId = $_SESSION['user'];
$resultUser = mysqli_query($conn,"SELECT * FROM `users` WHERE `id` =$sessionId");
$resUser = mysqli_fetch_assoc($resultUser);
$user = $resUser["user"];
$name = $resUser["name"];
$pic = $resUser["pic"];
$tel = $resUser["tel"];
$level = $resUser["level"];