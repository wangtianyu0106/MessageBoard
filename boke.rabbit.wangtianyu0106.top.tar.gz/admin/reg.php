<?php
//启动session会话
session_start();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>博客注册页面</title>
    <link href="https://cdn.bootcss.com/twitter-bootstrap/4.1.3/css/bootstrap.css" rel="stylesheet">
    <style>
        body{
            background: -webkit-radial-gradient(#6FA58D,#123B73);
            background: -o-radial-gradient(#6FA58D,#123B73);
            background: -moz-radial-gradient(#6FA58D,#123B73);
            background: radial-gradient(#6FA58D,#123B73);
            background-size:100% 100%;
            background-attachment: fixed;
        }
        .container{
            width: 500px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%,-50%);
        }
        .container input{
            margin: auto;
            display: block;
            padding: 10px 25px;
            border-radius: 20px;
            margin-bottom: 15px;
            border: 1px #a5a5a5 solid;
        }
        .container .submit{
            padding: 10px 35px;
        }
        .container{
            color: #fff9ec;
            text-align: center;
        }
        .container h2{
            font-family: 方正行楷简体;
            font-weight: 100;
            font-size: 36px;
        }
        .container .password,.container .user,.container .name,.container .tel{
            background-color: transparent;
        }
        input::-webkit-input-placeholder,textarea::-webkit-input-placeholder{
            color:#fff9ec;
        }

        input:-moz-placeholder,textarea:-moz-placeholder{
            color:#fff9ec;
        }

        input::-moz-placeholder,textarea::-moz-placeholder{
            color:#fff9ec;
        }
        input:-ms-input-placeholder,textarea:-ms-input-placeholder{
            color:#fff9ec;
        }
        .right{
            position: absolute;
            top: 20%;
            left: 40%;
            text-align: left;
        }
    </style>
</head>
<body>
<a href="../index.php" style="color: #0C0C0C;" class="right">返回首页</a>
<div class="container">
    <h2>博客注册</h2>
    <form action="reg-if.php" method="post">
        <input type="text" name="user" placeholder="请设置用户名" class="user" autofocus="autofocus">
        <input type="password" name="password" placeholder="请设置用户密码" class="password">
<!--        <input type="password" name="passwords" placeholder="请再确定密码" class="password">-->
        <input type="text" name="name" placeholder="请设置昵称" class="name">
        <input type="tel" name="tel" placeholder="请填写联系电话" class="tel">
        <input type="submit" value="注册" class="submit">
        <a href="login.php" style="color: #0C0C0C;float: right;margin-top: -50px">已有账号？点击注册</a>
    </form>
</div>

<?php
////var_dump($_POST);
//require_once "../config.php";
//
//$user = $_POST["user"];
//$password = $_POST["password"];
//$name = $_POST["name"];
//$tel = $_POST["tel"];
////var_dump($user);
//
//$reg = mysqli_query($conn,"SELECT * FROM `users` WHERE `user` LIKE '$user'");
//$regLen = mysqli_num_rows($reg);
//
////if(isset($_SESSION['$regLen'])){
////    if($_SESSION['$regLen'] !== 1){
////        echo "<script>alert('当前昵称重复了')</script>";
////        session_destroy();
////        header('Location:reg.php');
////    }
////};
?>
</body>
</html>