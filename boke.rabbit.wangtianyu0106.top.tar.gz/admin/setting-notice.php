<?php
require_once "header.php";
if ($level != 1){
    die("权限不足，不能访问");
}
?>
    <div class="col-12" style="background: #edfffd; margin-bottom: 15px">
        <h5>修改公告</h5>
    </div>
<!--            <h5>修改公告</h5>-->
            <?php
            //引入连接数据库的配置文件
            require_once "../config.php";

            //查询数据库
            $resultAll = mysqli_query($conn,"SELECT * FROM `notice`");

            //输出第一条数据
            $result = mysqli_fetch_assoc($resultAll);
            //        var_dump($result["content"]);
            $content = $result["content"]
            ?>
            <form action="update-notice.php" method="get" class="notice-form">
                <div class="form-group">
                    <input type="text" class="form-control" name="notice" class="user" value="<?php echo $content; ?>" autofocus="autofocus">
                </div>
                <input type="submit" value="修改" class="submit btn btn-primary">
            </form>
</div>
<?php
require_once "footer.php";
?>