<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
<?php
//启动session会话
session_start();

//var_dump($_POST);
//post方法接收到用户名
$user = $_POST["user"];
//var_dump($user);

//post方法接收到用户密码
$password = $_POST["password"];
//var_dump($password);
//引入配置文件
require_once "../config.php";

$result = mysqli_query($conn,"SELECT * FROM `users` WHERE `user` LIKE '$user' AND `password` LIKE '$password' ORDER BY `users`.`id` DESC");
$resultLen = mysqli_num_rows($result);
$res = mysqli_fetch_assoc($result);
//获取当前登录成功的用户id
$id = $res["id"];
//判断用户名和用户密码是否匹配
if($resultLen === 1){
    //登录成功赋值
    $_SESSION['user'] = $id;
    //跳转页面
    header('Location:index.php');
}else{
    //登录失败赋值
    $_SESSION['user'] = 0;
    //跳转页面
    header('Location:login.php');
}

////查询数据库中user表单
//$userResult = mysqli_query($conn,"SELECT * FROM `users` ORDER BY `users`.`id` DESC");
////echo "<pre>";
////var_dump($userResult);
////echo "</pre>";
//
////查询数据库中有多少条数据
//$userLength = mysqli_num_rows($userResult);
////var_dump($userLength);
//for($i=0;$i<$userLength;$i++){
//    //输出第一条数据
//    $userRes = mysqli_fetch_array($userResult);
//    echo "<pre>";
//    var_dump($userRes);
//    echo "</pre>";
////    var_dump($userResult["user"]);
////    var_dump($userResult["password"]);
//    $users = $userRes["user"];
//    $passwords = $userRes["password"];
////    var_dump($user == $users);
////    var_dump($password == $passwords);
//        if($users == $user && $passwords == $password){
////        //登录成功赋值
//        $_SESSION['user'] = 1;
//        echo 1;
//        //跳转页面
//        header('Location:index.php');
////            break;
//    }else{
////        //登录失败赋值
//        $_SESSION['user'] = 0;
//            echo 2;
////        //跳转页面
//        header('Location:login.php');
////        break;
//    }
////    break;
//}
